package com.sklabs.ecommerceapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EadCw2EcommerceRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
