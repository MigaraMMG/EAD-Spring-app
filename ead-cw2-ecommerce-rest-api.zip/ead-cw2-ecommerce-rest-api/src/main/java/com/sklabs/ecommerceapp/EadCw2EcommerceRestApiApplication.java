package com.sklabs.ecommerceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EadCw2EcommerceRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EadCw2EcommerceRestApiApplication.class, args);
	}

}
